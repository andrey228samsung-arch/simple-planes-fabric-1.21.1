package xyz.przemyk.simpleplanes.items;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.core.component.DataComponents;

/** Utilities for storing the plane's entity data on an item in modern Minecraft. */
public final class PlaneItemData {
    private PlaneItemData() {}

    public static CompoundTag getEntityTag(ItemStack stack) {
        CustomData customData = stack.get(DataComponents.CUSTOM_DATA);
        if (customData == null) return null;
        CompoundTag root = customData.copyTag();
        return root.contains("EntityTag", 10) ? root.getCompound("EntityTag") : null;
    }

    public static void setEntityTag(ItemStack stack, CompoundTag entityTag) {
        CustomData existing = stack.get(DataComponents.CUSTOM_DATA);
        CompoundTag root = existing == null ? new CompoundTag() : existing.copyTag();
        root.put("EntityTag", entityTag.copy());
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(root));
    }
}
