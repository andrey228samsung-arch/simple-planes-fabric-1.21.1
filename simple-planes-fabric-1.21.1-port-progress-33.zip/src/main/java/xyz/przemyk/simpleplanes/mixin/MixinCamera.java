package xyz.przemyk.simpleplanes.mixin;

import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.przemyk.simpleplanes.client.ClientEventHandler;

/** Applies the plane camera transform after vanilla has initialized this frame's camera. */
@Mixin(Camera.class)
public abstract class MixinCamera {
    @Inject(
            method = "setup(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/entity/Entity;ZZF)V",
            at = @At("TAIL")
    )
    private void simpleplanes$setupPlaneCamera(BlockGetter level, Entity entity, boolean detached,
                                                boolean thirdPersonReverse, float partialTick, CallbackInfo ci) {
        ClientEventHandler.onCameraSetup((Camera) (Object) this, partialTick);
    }
}
