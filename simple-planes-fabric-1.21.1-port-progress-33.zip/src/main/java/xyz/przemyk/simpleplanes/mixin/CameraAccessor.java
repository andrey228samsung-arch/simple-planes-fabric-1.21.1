package xyz.przemyk.simpleplanes.mixin;

import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Access to vanilla's protected rotation setter so camera angles and quaternion stay synchronized. */
@Mixin(Camera.class)
public interface CameraAccessor {
    @Invoker("setRotation")
    void simpleplanes$setRotation(float yaw, float pitch);
}
