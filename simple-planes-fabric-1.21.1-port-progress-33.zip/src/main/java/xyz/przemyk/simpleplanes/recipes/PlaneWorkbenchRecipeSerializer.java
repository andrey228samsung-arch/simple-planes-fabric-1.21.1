package xyz.przemyk.simpleplanes.recipes;

import com.mojang.serialization.MapCodec;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.crafting.RecipeSerializer;

public final class PlaneWorkbenchRecipeSerializer implements RecipeSerializer<PlaneWorkbenchRecipe> {
    @Override
    public MapCodec<PlaneWorkbenchRecipe> codec() {
        return PlaneWorkbenchRecipe.CODEC;
    }

    @Override
    public StreamCodec<RegistryFriendlyByteBuf, PlaneWorkbenchRecipe> streamCodec() {
        return PlaneWorkbenchRecipe.STREAM_CODEC;
    }
}
