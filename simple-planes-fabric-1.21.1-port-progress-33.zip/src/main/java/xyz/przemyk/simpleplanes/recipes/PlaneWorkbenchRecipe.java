package xyz.przemyk.simpleplanes.recipes;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.HolderLookup;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import xyz.przemyk.simpleplanes.setup.SimplePlanesRecipes;

public record PlaneWorkbenchRecipe(Ingredient ingredient,
                                  int ingredientAmount,
                                  int materialAmount,
                                  ItemStack result) implements Recipe<PlaneWorkbenchRecipeInput> {

    public static final MapCodec<PlaneWorkbenchRecipe> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Ingredient.CODEC.fieldOf("ingredient").forGetter(PlaneWorkbenchRecipe::ingredient),
            com.mojang.serialization.Codec.INT.fieldOf("ingredient_amount").forGetter(PlaneWorkbenchRecipe::ingredientAmount),
            com.mojang.serialization.Codec.INT.fieldOf("material_amount").forGetter(PlaneWorkbenchRecipe::materialAmount),
            ItemStack.CODEC.fieldOf("result").forGetter(PlaneWorkbenchRecipe::result)
    ).apply(instance, PlaneWorkbenchRecipe::new));

    public static final StreamCodec<RegistryFriendlyByteBuf, PlaneWorkbenchRecipe> STREAM_CODEC = StreamCodec.composite(
            Ingredient.CONTENTS_STREAM_CODEC, PlaneWorkbenchRecipe::ingredient,
            ByteBufCodecs.VAR_INT, PlaneWorkbenchRecipe::ingredientAmount,
            ByteBufCodecs.VAR_INT, PlaneWorkbenchRecipe::materialAmount,
            ItemStack.STREAM_CODEC, PlaneWorkbenchRecipe::result,
            PlaneWorkbenchRecipe::new
    );

    public boolean canCraft(ItemStack ingredientStack, ItemStack materialStack) {
        return ingredientAmount > 0 && materialAmount > 0
                && ingredientStack.getCount() >= ingredientAmount
                && materialStack.getCount() >= materialAmount
                && ingredient.test(ingredientStack);
    }

    @Override
    public boolean matches(PlaneWorkbenchRecipeInput input, Level level) {
        return canCraft(input.ingredient(), input.material());
    }

    @Override
    public ItemStack assemble(PlaneWorkbenchRecipeInput input, HolderLookup.Provider registries) {
        return result.copy();
    }

    @Override
    public ItemStack getResultItem(HolderLookup.Provider registries) {
        return result.copy();
    }

    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return width * height >= 2;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return SimplePlanesRecipes.PLANE_WORKBENCH_RECIPE_SERIALIZER;
    }

    @Override
    public RecipeType<?> getType() {
        return SimplePlanesRecipes.PLANE_WORKBENCH_RECIPE_TYPE;
    }

    @Override
    public boolean isSpecial() {
        return true;
    }
}
