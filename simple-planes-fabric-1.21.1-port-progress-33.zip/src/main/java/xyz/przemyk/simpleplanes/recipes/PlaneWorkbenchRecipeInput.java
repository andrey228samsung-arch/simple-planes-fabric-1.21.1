package xyz.przemyk.simpleplanes.recipes;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeInput;

/** Two input slots used by the plane workbench recipe. */
public record PlaneWorkbenchRecipeInput(ItemStack ingredient, ItemStack material) implements RecipeInput {
    @Override
    public ItemStack getItem(int index) {
        return switch (index) {
            case 0 -> ingredient;
            case 1 -> material;
            default -> ItemStack.EMPTY;
        };
    }

    @Override
    public int size() {
        return 2;
    }
}
