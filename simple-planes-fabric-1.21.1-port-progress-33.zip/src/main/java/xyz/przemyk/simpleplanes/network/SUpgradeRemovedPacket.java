package xyz.przemyk.simpleplanes.network;

import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import xyz.przemyk.simpleplanes.SimplePlanesMod;
import xyz.przemyk.simpleplanes.entities.PlaneEntity;

public class SUpgradeRemovedPacket {

    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, "s_remove_upgrade");
    public static final net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<RawPayload> TYPE = RawPayload.type(ID);

    public static void send(ResourceLocation upgradeID, int planeEntityID, PlaneEntity planeEntity) {
        FriendlyByteBuf buffer = new FriendlyByteBuf(io.netty.buffer.Unpooled.buffer());
        buffer.writeResourceLocation(upgradeID);
        buffer.writeVarInt(planeEntityID);

        RawPayload payload = RawPayload.fromBufferAndRelease(TYPE, buffer);
        for (ServerPlayer player : PlayerLookup.tracking(planeEntity)) {
            ServerPlayNetworking.send(player, payload);
        }
    }

    @SuppressWarnings("unused")
    public static void receive(Minecraft minecraft, ClientPacketListener clientPacketListener, FriendlyByteBuf buffer, PacketSender packetSender) {
        ResourceLocation upgradeID = buffer.readResourceLocation();
        int planeEntityID = buffer.readVarInt();
        buffer.release();
        minecraft.execute(() -> {
            ClientLevel clientWorld = minecraft.level;
            if (clientWorld != null && clientWorld.getEntity(planeEntityID) instanceof PlaneEntity planeEntity) {
                planeEntity.removeUpgrade(upgradeID);
            }
        });
    }
}
