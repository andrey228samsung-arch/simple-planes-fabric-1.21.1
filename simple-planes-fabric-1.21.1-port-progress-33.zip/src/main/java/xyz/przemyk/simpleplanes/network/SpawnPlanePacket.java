package xyz.przemyk.simpleplanes.network;

import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec3;
import xyz.przemyk.simpleplanes.SimplePlanesMod;
import xyz.przemyk.simpleplanes.entities.PlaneEntity;

import java.util.UUID;

public class SpawnPlanePacket {

    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, "spawn_plane");
    public static final net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<RawPayload> TYPE = RawPayload.type(ID);

    /**
     * Serializes the public spawn fields instead of relying on the removed 1.20-era
     * FriendlyByteBuf constructor/write methods on ClientboundAddEntityPacket.
     */
    public static FriendlyByteBuf createBuffer(PlaneEntity planeEntity) {
        FriendlyByteBuf buffer = new FriendlyByteBuf(io.netty.buffer.Unpooled.buffer());
        ClientboundAddEntityPacket packet = new ClientboundAddEntityPacket(planeEntity);
        writeAddEntityPacket(buffer, packet);
        planeEntity.writeSpawnData(buffer);
        return buffer;
    }

    private static void writeAddEntityPacket(FriendlyByteBuf buffer, ClientboundAddEntityPacket packet) {
        buffer.writeVarInt(packet.getId());
        buffer.writeUUID(packet.getUUID());
        buffer.writeVarInt(BuiltInRegistries.ENTITY_TYPE.getId(packet.getType()));
        buffer.writeDouble(packet.getX());
        buffer.writeDouble(packet.getY());
        buffer.writeDouble(packet.getZ());
        buffer.writeFloat(packet.getXRot());
        buffer.writeFloat(packet.getYRot());
        buffer.writeFloat(packet.getYHeadRot());
        buffer.writeVarInt(packet.getData());
        buffer.writeDouble(packet.getXa());
        buffer.writeDouble(packet.getYa());
        buffer.writeDouble(packet.getZa());
    }

    @SuppressWarnings("unused")
    public static void receive(Minecraft minecraft, ClientPacketListener clientPacketListener, FriendlyByteBuf buffer, PacketSender packetSender) {
        int entityId = buffer.readVarInt();
        UUID uuid = buffer.readUUID();
        int typeId = buffer.readVarInt();
        EntityType<?> entityType = BuiltInRegistries.ENTITY_TYPE.byId(typeId);
        double x = buffer.readDouble();
        double y = buffer.readDouble();
        double z = buffer.readDouble();
        float xRot = buffer.readFloat();
        float yRot = buffer.readFloat();
        float yHeadRot = buffer.readFloat();
        int data = buffer.readVarInt();
        Vec3 velocity = new Vec3(buffer.readDouble(), buffer.readDouble(), buffer.readDouble());

        if (entityType == null) {
            buffer.release();
            return;
        }

        ClientboundAddEntityPacket spawnPacket = new ClientboundAddEntityPacket(
                entityId, uuid, x, y, z, xRot, yRot, entityType, data, velocity, yHeadRot);
        minecraft.execute(() -> {
            try {
                spawnPacket.handle(clientPacketListener);
                ClientLevel clientWorld = minecraft.level;
                if (clientWorld != null && clientWorld.getEntity(entityId) instanceof PlaneEntity planeEntity) {
                    planeEntity.readSpawnData(buffer);
                }
            } finally {
                buffer.release();
            }
        });
    }
}
