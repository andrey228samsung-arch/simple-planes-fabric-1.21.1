package xyz.przemyk.simpleplanes.network;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import xyz.przemyk.simpleplanes.SimplePlanesMod;
import xyz.przemyk.simpleplanes.entities.PlaneEntity;

public class YawPacket {

    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, "yaw");
    public static final net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<RawPayload> TYPE = RawPayload.type(ID);

    public static void send(byte yawRight) {
        FriendlyByteBuf buffer = new FriendlyByteBuf(io.netty.buffer.Unpooled.buffer());
        buffer.writeByte(yawRight);
        ClientPlayNetworking.send(RawPayload.fromBufferAndRelease(TYPE, buffer));
    }

    @SuppressWarnings("unused")
    public static void receive(MinecraftServer server, ServerPlayer sender, ServerGamePacketListenerImpl serverGamePacketListener, FriendlyByteBuf buffer, PacketSender packetSender) {
        byte yawRight = buffer.readByte();
        server.execute(() -> {
            if (sender != null && sender.getVehicle() instanceof PlaneEntity planeEntity && planeEntity.getControllingPassenger() == sender) {
                planeEntity.setYawRight(yawRight);
            }
        });
    }
}
