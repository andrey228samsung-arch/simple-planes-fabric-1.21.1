package xyz.przemyk.simpleplanes.network;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import xyz.przemyk.simpleplanes.SimplePlanesMod;
import xyz.przemyk.simpleplanes.entities.PlaneEntity;

public class ChangeThrottlePacket {

    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, "throttle");
    public static final net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<RawPayload> TYPE = RawPayload.type(ID);

    public static void send(Type type) {
        FriendlyByteBuf buffer = new FriendlyByteBuf(io.netty.buffer.Unpooled.buffer());
        buffer.writeByte(type.ordinal());
        ClientPlayNetworking.send(RawPayload.fromBufferAndRelease(TYPE, buffer));
    }

    @SuppressWarnings("unused")
    public static void receive(MinecraftServer server, ServerPlayer sender, ServerGamePacketListenerImpl serverGamePacketListener, FriendlyByteBuf buffer, PacketSender packetSender) {
        int ordinal = buffer.readUnsignedByte();
        Type[] types = Type.values();
        // Never let a malformed custom payload crash the server with an array index error.
        if (ordinal >= types.length) {
            return;
        }
        Type type = types[ordinal];
        server.execute(() -> {
            if (sender != null && sender.getVehicle() instanceof PlaneEntity planeEntity && planeEntity.getControllingPassenger() == sender) {
                planeEntity.changeThrottle(type);
            }
        });
    }

    public enum Type {
        UP,
        DOWN
    }
}
