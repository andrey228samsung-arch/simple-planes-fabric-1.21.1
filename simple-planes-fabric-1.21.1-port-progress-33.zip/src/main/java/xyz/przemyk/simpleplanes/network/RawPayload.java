package xyz.przemyk.simpleplanes.network;

import io.netty.buffer.Unpooled;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Bridges the old packet serializers to Minecraft 1.21.1 typed custom payloads. */
public record RawPayload(CustomPacketPayload.Type<RawPayload> type, byte[] data) implements CustomPacketPayload {
    /** Defensive cap for legacy byte-array packets carried inside typed payloads. */
    public static final int MAX_PAYLOAD_BYTES = 1_048_576;

    public RawPayload {
        if (type == null) {
            throw new IllegalArgumentException("Payload type must not be null");
        }
        if (data == null) {
            throw new IllegalArgumentException("Payload data must not be null");
        }
        if (data.length > MAX_PAYLOAD_BYTES) {
            throw new IllegalArgumentException("Simple Planes payload exceeds " + MAX_PAYLOAD_BYTES + " bytes");
        }
        data = data.clone();
    }

    /** Prevent callers from mutating the payload after it has been queued for sending. */
    @Override
    public byte[] data() {
        return data.clone();
    }
    public static CustomPacketPayload.Type<RawPayload> type(ResourceLocation id) {
        return new CustomPacketPayload.Type<>(id);
    }

    public static StreamCodec<RegistryFriendlyByteBuf, RawPayload> codec(CustomPacketPayload.Type<RawPayload> type) {
        return StreamCodec.of((buf, payload) -> buf.writeByteArray(payload.data),
                buf -> new RawPayload(type, buf.readByteArray(MAX_PAYLOAD_BYTES)));
    }

    public static RawPayload fromBuffer(CustomPacketPayload.Type<RawPayload> type, FriendlyByteBuf buffer) {
        byte[] data = new byte[buffer.readableBytes()];
        buffer.getBytes(buffer.readerIndex(), data);
        return new RawPayload(type, data);
    }

    /** Copies a temporary packet buffer and releases its Netty reference-counted storage. */
    public static RawPayload fromBufferAndRelease(CustomPacketPayload.Type<RawPayload> type, FriendlyByteBuf buffer) {
        try {
            return fromBuffer(type, buffer);
        } finally {
            buffer.release();
        }
    }

    public static RawPayload empty(CustomPacketPayload.Type<RawPayload> type) {
        return new RawPayload(type, new byte[0]);
    }

    public FriendlyByteBuf toBuffer() {
        return new FriendlyByteBuf(Unpooled.wrappedBuffer(data));
    }

    @Override
    public CustomPacketPayload.Type<RawPayload> type() {
        return type;
    }
}
