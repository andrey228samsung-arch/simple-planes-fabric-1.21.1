package xyz.przemyk.simpleplanes.network;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.Entity;
import xyz.przemyk.simpleplanes.SimplePlanesMod;
import xyz.przemyk.simpleplanes.entities.PlaneEntity;
import xyz.przemyk.simpleplanes.upgrades.Upgrade;

@SuppressWarnings({"unused", "EmptyMethod"})
public class DropPayloadPacket {

    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, "drop_payload");
    public static final net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<RawPayload> TYPE = RawPayload.type(ID);

    public static void send() {
        ClientPlayNetworking.send(RawPayload.empty(TYPE));
    }

    public static void receive(MinecraftServer server, ServerPlayer sender, ServerGamePacketListenerImpl serverGamePacketListener, FriendlyByteBuf buffer, PacketSender packetSender) {
        server.execute(() -> {
            Entity entity = sender.getVehicle();
            if (entity instanceof PlaneEntity planeEntity) {
                for (Upgrade upgrade : planeEntity.upgrades.values()) {
                    if (upgrade.canBeDroppedAsPayload()) {
                        upgrade.dropAsPayload();
                        break;
                    }
                }
            }
        });
    }
}
