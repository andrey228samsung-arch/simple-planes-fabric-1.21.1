package xyz.przemyk.simpleplanes.network;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import xyz.przemyk.simpleplanes.SimplePlanesMod;
import xyz.przemyk.simpleplanes.container.PlaneWorkbenchContainer;

public class CycleItemsPacket {

    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, "cycle_items");
    public static final net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<RawPayload> TYPE = RawPayload.type(ID);

    public static void send(Type type) {
        FriendlyByteBuf buffer = new FriendlyByteBuf(io.netty.buffer.Unpooled.buffer());
        buffer.writeByte(type.ordinal());
        ClientPlayNetworking.send(RawPayload.fromBufferAndRelease(TYPE, buffer));
    }

    @SuppressWarnings("unused")
    public static void receive(MinecraftServer server, ServerPlayer sender, ServerGamePacketListenerImpl serverGamePacketListener, FriendlyByteBuf buffer, PacketSender packetSender) {
        int ordinal = buffer.readUnsignedByte();
        Type[] types = Type.values();
        // Reject unknown actions instead of indexing the enum array with untrusted packet data.
        if (ordinal >= types.length) {
            return;
        }
        Type type = types[ordinal];
        server.execute(() -> {
            if (sender != null && sender.containerMenu instanceof PlaneWorkbenchContainer workbenchContainer) {
                workbenchContainer.cycleItems(type);
            }
        });
    }

    public enum Type {
        CRAFTING_LEFT,
        CRAFTING_RIGHT
    }
}
