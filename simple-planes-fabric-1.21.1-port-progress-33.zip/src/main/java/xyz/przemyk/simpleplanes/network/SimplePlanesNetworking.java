package xyz.przemyk.simpleplanes.network;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;
import java.util.function.Consumer;

public class SimplePlanesNetworking {
    /** Must be called from the common initializer before any receiver is registered. */
    public static void registerPayloadTypes() {
        registerC2SType(CycleItemsPacket.TYPE, CycleItemsPacket.ID);
        registerC2SType(RotationPacket.TYPE, RotationPacket.ID);
        registerC2SType(ChangeThrottlePacket.TYPE, ChangeThrottlePacket.ID);
        registerC2SType(YawPacket.TYPE, YawPacket.ID);
        registerC2SType(PitchPacket.TYPE, PitchPacket.ID);
        registerC2SType(MoveHeliUpPacket.TYPE, MoveHeliUpPacket.ID);
        registerC2SType(OpenPlaneInventoryPacket.TYPE, OpenPlaneInventoryPacket.ID);
        registerC2SType(OpenInventoryPacket.TYPE, OpenInventoryPacket.ID);
        registerC2SType(CRemoveUpgradePacket.TYPE, CRemoveUpgradePacket.ID);
        registerC2SType(DropPayloadPacket.TYPE, DropPayloadPacket.ID);
        registerS2CType(UpdateUpgradePacket.TYPE, UpdateUpgradePacket.ID);
        registerS2CType(SUpgradeRemovedPacket.TYPE, SUpgradeRemovedPacket.ID);
        registerS2CType(SpawnPlanePacket.TYPE, SpawnPlanePacket.ID);
        registerS2CType(JukeboxPacket.TYPE, JukeboxPacket.ID);
    }

    private static void registerC2SType(net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<RawPayload> type, net.minecraft.resources.ResourceLocation id) {
        PayloadTypeRegistry.playC2S().register(type, RawPayload.codec(type));
    }

    private static void registerS2CType(net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<RawPayload> type, net.minecraft.resources.ResourceLocation id) {
        PayloadTypeRegistry.playS2C().register(type, RawPayload.codec(type));
    }

    public static void registerS2CPackets() {
        ClientPlayNetworking.registerGlobalReceiver(UpdateUpgradePacket.TYPE, (payload, context) -> UpdateUpgradePacket.receive(context.client(), context.client().getConnection(), payload.toBuffer(), null));
        ClientPlayNetworking.registerGlobalReceiver(SUpgradeRemovedPacket.TYPE, (payload, context) -> SUpgradeRemovedPacket.receive(context.client(), context.client().getConnection(), payload.toBuffer(), null));
        ClientPlayNetworking.registerGlobalReceiver(SpawnPlanePacket.TYPE, (payload, context) -> SpawnPlanePacket.receive(context.client(), context.client().getConnection(), payload.toBuffer(), null));
        ClientPlayNetworking.registerGlobalReceiver(JukeboxPacket.TYPE, (payload, context) -> JukeboxPacket.receive(context.client(), context.client().getConnection(), payload.toBuffer(), null));
    }

    /** Server packet handlers decode synchronously before scheduling world mutations. */
    private static void receiveServer(RawPayload payload, Consumer<FriendlyByteBuf> receiver) {
        FriendlyByteBuf buffer = payload.toBuffer();
        try {
            receiver.accept(buffer);
        } finally {
            buffer.release();
        }
    }

    public static void registerC2SPackets() {
        ServerPlayNetworking.registerGlobalReceiver(CycleItemsPacket.TYPE, (payload, context) -> receiveServer(payload, buffer -> CycleItemsPacket.receive(context.server(), context.player(), null, buffer, null)));
        ServerPlayNetworking.registerGlobalReceiver(RotationPacket.TYPE, (payload, context) -> receiveServer(payload, buffer -> RotationPacket.receive(context.server(), context.player(), null, buffer, null)));
        ServerPlayNetworking.registerGlobalReceiver(ChangeThrottlePacket.TYPE, (payload, context) -> receiveServer(payload, buffer -> ChangeThrottlePacket.receive(context.server(), context.player(), null, buffer, null)));
        ServerPlayNetworking.registerGlobalReceiver(YawPacket.TYPE, (payload, context) -> receiveServer(payload, buffer -> YawPacket.receive(context.server(), context.player(), null, buffer, null)));
        ServerPlayNetworking.registerGlobalReceiver(PitchPacket.TYPE, (payload, context) -> receiveServer(payload, buffer -> PitchPacket.receive(context.server(), context.player(), null, buffer, null)));
        ServerPlayNetworking.registerGlobalReceiver(MoveHeliUpPacket.TYPE, (payload, context) -> receiveServer(payload, buffer -> MoveHeliUpPacket.receive(context.server(), context.player(), null, buffer, null)));
        ServerPlayNetworking.registerGlobalReceiver(OpenPlaneInventoryPacket.TYPE, (payload, context) -> receiveServer(payload, buffer -> OpenPlaneInventoryPacket.receive(context.server(), context.player(), null, buffer, null)));
        ServerPlayNetworking.registerGlobalReceiver(OpenInventoryPacket.TYPE, (payload, context) -> receiveServer(payload, buffer -> OpenInventoryPacket.receive(context.server(), context.player(), null, buffer, null)));
        ServerPlayNetworking.registerGlobalReceiver(CRemoveUpgradePacket.TYPE, (payload, context) -> receiveServer(payload, buffer -> CRemoveUpgradePacket.receive(context.server(), context.player(), null, buffer, null)));
        ServerPlayNetworking.registerGlobalReceiver(DropPayloadPacket.TYPE, (payload, context) -> receiveServer(payload, buffer -> DropPayloadPacket.receive(context.server(), context.player(), null, buffer, null)));
    }
}
