package xyz.przemyk.simpleplanes.network;

import io.netty.buffer.ByteBuf;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import xyz.przemyk.simpleplanes.SimplePlanesMod;
import xyz.przemyk.simpleplanes.entities.PlaneEntity;

public class UpdateUpgradePacket {

    public static final ResourceLocation ID = ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, "update_upgrade");
    public static final net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type<RawPayload> TYPE = RawPayload.type(ID);

    public static void send(ResourceLocation upgradeID, boolean newUpgrade, PlaneEntity planeEntity) {
        FriendlyByteBuf buffer = new FriendlyByteBuf(io.netty.buffer.Unpooled.buffer());
        buffer.writeBoolean(newUpgrade);
        planeEntity.writeUpdateUpgradePacket(upgradeID, buffer);

        RawPayload payload = RawPayload.fromBufferAndRelease(TYPE, buffer);
        for (ServerPlayer player : PlayerLookup.tracking(planeEntity)) {
            ServerPlayNetworking.send(player, payload);
        }
    }

    @SuppressWarnings("unused")
    public static void receive(Minecraft minecraft, ClientPacketListener clientPacketListener, FriendlyByteBuf buffer, PacketSender packetSender) {
        boolean newUpgrade = buffer.readBoolean();
        int planeEntityID = buffer.readVarInt();
        ResourceLocation upgradeID = buffer.readResourceLocation();
//        FriendlyByteBuf copiedBuffer = new FriendlyByteBuf(buffer.copy());
        minecraft.execute(() -> {
            try {
                ClientLevel clientWorld = minecraft.level;
                if (clientWorld == null) {
                    return;
                }
                if (clientWorld.getEntity(planeEntityID) instanceof PlaneEntity planeEntity) {
                    planeEntity.readUpdateUpgradePacket(upgradeID, buffer, newUpgrade);
                }
            } finally {
                buffer.release();
            }
        });
    }
}
