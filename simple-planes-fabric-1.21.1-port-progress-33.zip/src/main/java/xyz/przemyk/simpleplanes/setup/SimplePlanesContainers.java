package xyz.przemyk.simpleplanes.setup;



import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.network.codec.ByteBufCodecs;
import xyz.przemyk.simpleplanes.SimplePlanesMod;
import xyz.przemyk.simpleplanes.container.PlaneInventoryContainer;
import xyz.przemyk.simpleplanes.container.PlaneWorkbenchContainer;
import xyz.przemyk.simpleplanes.container.RemoveUpgradesContainer;
import xyz.przemyk.simpleplanes.container.StorageContainer;

public class SimplePlanesContainers {

    public static void init() {
    }

    public static final MenuType<PlaneWorkbenchContainer> PLANE_WORKBENCH = register("plane_workbench", new MenuType<>(PlaneWorkbenchContainer::new, FeatureFlags.DEFAULT_FLAGS));
    public static final MenuType<RemoveUpgradesContainer> UPGRADES_REMOVAL = register("upgrades_removal", new ExtendedScreenHandlerType<>((id, inventory, planeId) -> new RemoveUpgradesContainer(id, planeId), ByteBufCodecs.VAR_INT));
    public static final MenuType<StorageContainer> STORAGE = register("storage", new ExtendedScreenHandlerType<>((id, inventory, chestType) -> new StorageContainer(id, inventory, chestType), ByteBufCodecs.STRING_UTF8));
    public static final MenuType<PlaneInventoryContainer> PLANE_INVENTORY = register("plane_inventory", new ExtendedScreenHandlerType<>((id, inventory, planeId) -> new PlaneInventoryContainer(id, inventory, planeId), ByteBufCodecs.VAR_INT));

    private static <T extends AbstractContainerMenu> MenuType<T> register(String id, MenuType<T> container) {
        return Registry.register(BuiltInRegistries.MENU, ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, id), container);
    }
}
