package xyz.przemyk.simpleplanes.setup;



import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import xyz.przemyk.simpleplanes.SimplePlanesMod;

public class SimplePlanesSounds {
    public static void init() {
    }

    public static final SoundEvent PLANE_LOOP_SOUND_EVENT = Registry.register(BuiltInRegistries.SOUND_EVENT, ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, "plane_loop"), new SoundEvent(ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, "plane_loop")));
}