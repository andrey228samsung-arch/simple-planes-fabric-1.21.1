package xyz.przemyk.simpleplanes.setup;



import net.minecraft.core.registries.BuiltInRegistries;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.core.Registry;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.*;
import xyz.przemyk.simpleplanes.SimplePlanesMod;
import xyz.przemyk.simpleplanes.items.DescriptionItem;
import xyz.przemyk.simpleplanes.items.ParachuteItem;
import xyz.przemyk.simpleplanes.items.PlaneArmorItem;
import xyz.przemyk.simpleplanes.items.PlaneItem;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class SimplePlanesItems {

    public static void init() {
//        register(FMLJavaModLoadingContext.get().getModEventBus());
    }

    public static final CreativeModeTab ITEM_GROUP = Registry.register(
            BuiltInRegistries.CREATIVE_MODE_TAB,
            ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, "simple_planes"),
            FabricItemGroup.builder()
                    .title(Component.translatable("itemGroup.simpleplanes.simple_planes"))
                    .icon(() -> new ItemStack(PLANE_ITEM))
                    .displayItems((context, entries) -> {
                        entries.accept(PROPELLER);
                        entries.accept(FLOATY_BEDDING);
                        entries.accept(BOOSTER);
                        entries.accept(HEALING);
                        entries.accept(ARMOR);
                        entries.accept(FOLDING);
                        entries.accept(SUPPLY_CRATE);
                        entries.accept(SEATS);
                        entries.accept(ELECTRIC_ENGINE);
                        entries.accept(FURNACE_ENGINE);
                        entries.accept(LIQUID_ENGINE);
                        entries.accept(WRENCH);
                        entries.accept(PLANE_WORKBENCH);
                        entries.accept(CHARGING_STATION);
                        PLANE_ITEM.addMaterialVariants(entries::accept);
                        LARGE_PLANE_ITEM.addMaterialVariants(entries::accept);
                        HELICOPTER_ITEM.addMaterialVariants(entries::accept);
                        entries.accept(PARACHUTE_ITEM);
                    })
                    .build());

    public static List<PlaneItem> getPlaneItems() {
        ArrayList<PlaneItem> planeItems = new ArrayList<>(3);
        planeItems.add(PLANE_ITEM);
        planeItems.add(LARGE_PLANE_ITEM);
        planeItems.add(HELICOPTER_ITEM);
        return planeItems;
    }

    public static final Item PROPELLER = register("propeller", new Item(new Item.Properties()));

    public static final Item FLOATY_BEDDING = register("floaty_bedding", new Item(new Item.Properties()));
    public static final Item BOOSTER = register("booster", new Item(new Item.Properties()));
    public static final Item HEALING = register("healing", new Item(new Item.Properties()));
    public static final Item ARMOR = register("armor", new PlaneArmorItem(new Item.Properties().stacksTo(1)));
//    public static final Item SOLAR_PANEL = register("solar_panel", new Item(new Item.Properties().stacksTo(1)));
    public static final Item FOLDING = register("folding", new Item(new Item.Properties()));
    public static final Item SUPPLY_CRATE = register("supply_crate", new Item(new Item.Properties()));
    public static final Item SEATS = register("seats", new Item(new Item.Properties()));

    public static final Item ELECTRIC_ENGINE = register("electric_engine", new DescriptionItem(new Item.Properties(), Component.translatable(SimplePlanesMod.MODID + ".press_key", Component.keybind("key.plane_inventory_open.desc"))));
    public static final Item FURNACE_ENGINE = register("furnace_engine", new DescriptionItem(new Item.Properties(), Component.translatable(SimplePlanesMod.MODID + ".press_key", Component.keybind("key.plane_inventory_open.desc"))));
    public static final Item LIQUID_ENGINE = register("liquid_engine", new DescriptionItem(new Item.Properties(), Component.translatable(SimplePlanesMod.MODID + ".press_key", Component.keybind("key.plane_inventory_open.desc"))));

    public static final Item WRENCH = register("wrench", new Item(new Item.Properties()));
    public static final BlockItem PLANE_WORKBENCH = register("plane_workbench", new BlockItem(SimplePlanesBlocks.PLANE_WORKBENCH_BLOCK, new Item.Properties()));
    public static final BlockItem CHARGING_STATION = register("charging_station", new BlockItem(SimplePlanesBlocks.CHARGING_STATION_BLOCK, new Item.Properties()));

    public static final PlaneItem PLANE_ITEM = register("plane", new PlaneItem(new Item.Properties(), SimplePlanesEntities.PLANE));
    public static final PlaneItem LARGE_PLANE_ITEM = register("large_plane", new PlaneItem(new Item.Properties(), SimplePlanesEntities.LARGE_PLANE));
    public static final PlaneItem HELICOPTER_ITEM = register("helicopter", new PlaneItem(new Item.Properties(), SimplePlanesEntities.HELICOPTER));

    public static final ParachuteItem PARACHUTE_ITEM = register("parachute", new ParachuteItem(new Item.Properties()));

    private static <T extends Item> T register(String id, T item) {
        return Registry.register(BuiltInRegistries.ITEM, ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, id), item);
    }
}
