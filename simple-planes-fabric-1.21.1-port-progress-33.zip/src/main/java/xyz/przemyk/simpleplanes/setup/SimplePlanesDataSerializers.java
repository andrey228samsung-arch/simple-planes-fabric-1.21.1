package xyz.przemyk.simpleplanes.setup;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityDataRegistry;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.syncher.EntityDataSerializer;
import org.joml.Quaternionf;
import xyz.przemyk.simpleplanes.SimplePlanesMod;
import net.minecraft.resources.ResourceLocation;

/** Entity tracked-data serializers used by Simple Planes. */
public final class SimplePlanesDataSerializers {
    private SimplePlanesDataSerializers() {
    }

    public static void init() {
        FabricEntityDataRegistry.register(
                ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, "quaternion"),
                QUATERNION_SERIALIZER_ENTRY
        );
    }

    public static final EntityDataSerializer<Quaternionf> QUATERNION_SERIALIZER_ENTRY = new EntityDataSerializer<>() {
        private final StreamCodec<RegistryFriendlyByteBuf, Quaternionf> codec = StreamCodec.of(
                (buffer, quaternion) -> {
                    buffer.writeFloat(quaternion.x());
                    buffer.writeFloat(quaternion.y());
                    buffer.writeFloat(quaternion.z());
                    buffer.writeFloat(quaternion.w());
                },
                buffer -> new Quaternionf(
                        buffer.readFloat(),
                        buffer.readFloat(),
                        buffer.readFloat(),
                        buffer.readFloat()
                )
        );

        @Override
        public StreamCodec<? super RegistryFriendlyByteBuf, Quaternionf> codec() {
            return codec;
        }

        @Override
        public Quaternionf copy(Quaternionf quaternion) {
            return new Quaternionf(quaternion);
        }
    };
}
