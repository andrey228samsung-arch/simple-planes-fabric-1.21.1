package xyz.przemyk.simpleplanes.setup;



import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import xyz.przemyk.simpleplanes.SimplePlanesMod;
import xyz.przemyk.simpleplanes.entities.*;

@SuppressWarnings("unused")
public class SimplePlanesEntities {

    public static void init() {

    }

    public static final EntityType<PlaneEntity> PLANE = Registry.register(BuiltInRegistries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, "plane"), createEntityType(PlaneEntity::new, EntityDimensions.scalable(2.5F, 1.8F), "simpleplanes:plane"));
    public static final EntityType<LargePlaneEntity> LARGE_PLANE = Registry.register(BuiltInRegistries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, "large_plane"), createEntityType(LargePlaneEntity::new, EntityDimensions.scalable(3F, 2.3F), "simpleplanes:large_plane"));
    public static final EntityType<HelicopterEntity> HELICOPTER = Registry.register(BuiltInRegistries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, "helicopter"), createEntityType(HelicopterEntity::new, EntityDimensions.scalable(2.5F, 2.2F), "simpleplanes:helicopter"));

    public static final EntityType<ParachuteEntity> PARACHUTE = Registry.register(BuiltInRegistries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(SimplePlanesMod.MODID, "parachute"), createEntityType(ParachuteEntity::new, EntityDimensions.scalable(1.0F, 1.0F), "simpleplanes:parachute"));

    private static <T extends Entity> EntityType<T> createEntityType(EntityType.EntityFactory<T> factory, EntityDimensions size, String id) {
        return EntityType.Builder.of(factory, MobCategory.MISC)
                .sized(size.width, size.height)
                .clientTrackingRange(5)
                .updateInterval(3)
                .build(id);
    }
}
