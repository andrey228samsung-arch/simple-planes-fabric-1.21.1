#!/usr/bin/env python3
"""Offline structural checks for the Simple Planes Fabric 1.21.1 source port."""
from __future__ import annotations
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
checks = 0

def check(condition: bool, message: str) -> None:
    global checks
    checks += 1
    if not condition:
        errors.append(message)

# Parse every JSON resource and metadata file.
json_files = sorted((ROOT / "src/main/resources").rglob("*.json"))
for path in json_files:
    try:
        json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"Invalid JSON {path.relative_to(ROOT)}: {exc}")
check(bool(json_files), "No JSON resource files found")

metadata_path = ROOT / "src/main/resources/fabric.mod.json"
metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
check(metadata.get("id") == "simpleplanes", "fabric.mod.json id must be simpleplanes")
check(metadata.get("depends", {}).get("minecraft") == "~1.21.1", "Minecraft dependency must target ~1.21.1")
check(metadata.get("depends", {}).get("fabric-api") == "*", "fabric-api dependency must be declared")

# Check metadata-declared resources, which otherwise fail only when Fabric loads the mod.
icon_path = metadata.get("icon")
if icon_path:
    check((ROOT / "src/main/resources" / icon_path).is_file(), f"Missing mod icon resource: {icon_path}")
access_widener = metadata.get("accessWidener")
if access_widener:
    check((ROOT / "src/main/resources" / access_widener).is_file(), f"Missing access widener: {access_widener}")
for mixin_config in metadata.get("mixins", []):
    config_path = ROOT / "src/main/resources" / mixin_config
    check(config_path.is_file(), f"Missing mixin config resource: {mixin_config}")

for side in ("main", "client"):
    for entrypoint in metadata.get("entrypoints", {}).get(side, []):
        source = ROOT / "src/main/java" / Path(*entrypoint.split("."))
        check(source.with_suffix(".java").exists(), f"Missing {side} entrypoint source: {entrypoint}")

# Ensure the configured mixin classes exist and referenced payload identifiers are unique.
mixin_path = ROOT / "src/main/resources/simpleplanes.mixins.json"
mixins = json.loads(mixin_path.read_text(encoding="utf-8"))
package = mixins.get("package", "")
for name in mixins.get("client", []) + mixins.get("mixins", []):
    source = ROOT / "src/main/java" / Path(*package.split(".")) / f"{name}.java"
    check(source.exists(), f"Missing configured mixin source: {name}")

network_dir = ROOT / "src/main/java/xyz/przemyk/simpleplanes/network"
ids: dict[str, str] = {}
for path in sorted(network_dir.glob("*.java")):
    text = path.read_text(encoding="utf-8")
    match = re.search(r'public static final ResourceLocation ID = ResourceLocation\.fromNamespaceAndPath\(SimplePlanesMod\.MODID,\s*"([^"]+)"\)', text)
    if match:
        packet_id = match.group(1)
        check(packet_id not in ids, f"Duplicate packet ID '{packet_id}' in {path.name} and {ids.get(packet_id)}")
        ids[packet_id] = path.name
check("RawPayload.java" in [p.name for p in network_dir.glob("*.java")], "RawPayload compatibility bridge is missing")

java_files = list((ROOT / "src/main/java").rglob("*.java"))
check(len(java_files) >= 100, f"Expected full source tree; only found {len(java_files)} Java files")
print(f"Checked {checks} structural assertions, {len(json_files)} JSON files, {len(java_files)} Java files, {len(ids)} packet IDs.")
if errors:
    print("FAIL:")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)
print("PASS: offline structure and metadata checks succeeded. This does not replace Gradle compilation or an in-game test.")
